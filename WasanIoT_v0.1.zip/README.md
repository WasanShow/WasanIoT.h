# WasanIoT Library

Library สำหรับ Arduino เพื่อเชื่อมต่อกับ WasanDIY IoT Platform

## การติดตั้ง

### วิธีที่ 1: ติดตั้งผ่าน Arduino IDE
1. เปิด Arduino IDE
2. ไปที่ **Sketch > Include Library > Add .ZIP Library**
3. เลือกไฟล์ ZIP ของ WasanIoT Library
4. Library จะถูกติดตั้งใน `Arduino/libraries/WasanIoT/`

### วิธีที่ 2: ติดตั้งแบบ Manual
1. คัดลอกไฟล์ต่อไปนี้ไปยัง `Arduino/libraries/WasanIoT/`:
   - `WasanIoT.h`
   - `WasanIoT.cpp`
   - `library.properties`
   - `keywords.txt`

## การใช้งาน

### 1. Include Library
```cpp
#include "WasanIoT.h"
```

### 2. กำหนดค่า Configuration
```cpp
const char* WIFI_SSID = "YOUR_WIFI";
const char* WIFI_PASS = "YOUR_PASS";
const char* HOST = "192.168.1.100";
const uint16_t PORT = 4000;
const char* PROJECT_ID = "your_project_id";
const char* DEVICE_ID = "your_device_id";
const char* API_KEY = "your_api_key";
```

### 3. สร้าง Instance
```cpp
WasanIoT wasan(WIFI_SSID, WIFI_PASS, HOST, PORT, PROJECT_ID, DEVICE_ID, API_KEY);
```

### 4. เชื่อมต่อ WiFi
```cpp
void setup() {
    if (wasan.begin()) {
        Serial.println("WiFi connected!");
    }
}
```

### 5. ส่งข้อมูล Sensor
```cpp
// ส่งข้อมูลอุณหภูมิ
wasan.sendData("temperature", 25.5);

// ส่งข้อมูลความชื้น
wasan.sendData("humidity", 60);

// ส่งข้อมูลสถานะ
wasan.sendData("status", "online");
```

### 6. รับคำสั่งควบคุม
```cpp
void loop() {
    String response = wasan.pollCommands();
    
    if (response.length() > 0) {
        // ตรวจสอบคำสั่ง LED
        if (wasan.hasCommand(response, "power")) {
            bool state = wasan.getCommandValue(response, "power");
            digitalWrite(LED_PIN, state ? HIGH : LOW);
        }
        
        // ตรวจสอบคำสั่ง Slider
        if (wasan.hasCommand(response, "brightness")) {
            int value = wasan.getCommandIntValue(response, "brightness");
            analogWrite(LED_PIN, value);
        }
    }
}
```

## ฟังก์ชันหลัก

### การเชื่อมต่อ
- `begin()` - เชื่อมต่อ WiFi
- `isConnected()` - ตรวจสอบการเชื่อมต่อ

### การส่งข้อมูล
- `sendData(key, value)` - ส่งข้อมูล (รองรับ float, int, bool, String)

### การรับคำสั่ง
- `pollCommands()` - รับคำสั่งจากเซิร์ฟเวอร์
- `hasCommand(response, command)` - ตรวจสอบว่ามีคำสั่งหรือไม่
- `getCommandValue(response, command)` - รับค่า boolean
- `getCommandIntValue(response, command)` - รับค่า integer
- `getCommandFloatValue(response, command)` - รับค่า float
- `getCommandStringValue(response, command)` - รับค่า string

## ตัวอย่างการใช้งาน

ดูไฟล์ตัวอย่าง:
- `WasanIoT_Simple_Example.ino` - ตัวอย่างพื้นฐาน
- `WasanIoT_DHT22_Example.ino` - ตัวอย่างกับ DHT22 sensor
- `WasanIoT_Library_Example.ino` - ตัวอย่างครบถ้วน

## การแก้ไขปัญหา

### WiFi ไม่เชื่อมต่อ
- ตรวจสอบ SSID และ Password
- ตรวจสอบสัญญาณ WiFi
- เพิ่ม delay ใน loop

### ข้อมูลไม่ส่ง
- ตรวจสอบ HOST และ PORT
- ตรวจสอบ PROJECT_ID และ DEVICE_ID
- ตรวจสอบ API_KEY

### คำสั่งไม่ทำงาน
- ตรวจสอบ command name ใน widget
- ตรวจสอบ response format
- เพิ่ม debug print

## License

MIT License - ใช้งานได้อย่างอิสระ
