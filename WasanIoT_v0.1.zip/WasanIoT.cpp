#include "WasanIoT.h"

// Constructor
WasanIoT::WasanIoT(const char* ssid, const char* password, const char* host, uint16_t port, 
                   const char* projectId, const char* deviceId, const char* apiKey) {
    _ssid = ssid;
    _password = password;
    _host = host;
    _port = port;
    _projectId = projectId;
    _deviceId = deviceId;
    _apiKey = apiKey;
}

// Initialize WiFi connection
bool WasanIoT::begin() {
    Serial.println("Connecting to WiFi...");
    WiFi.begin(_ssid, _password);
    
    int attempts = 0;
    while (WiFi.status() != WL_CONNECTED && attempts < 20) {
        delay(500);
        Serial.print(".");
        attempts++;
    }
    
    if (WiFi.status() == WL_CONNECTED) {
        Serial.println("\nWiFi connected!");
        Serial.print("IP: ");
        Serial.println(WiFi.localIP());
        return true;
    } else {
        Serial.println("\nWiFi connection failed!");
        return false;
    }
}

// Send data methods
bool WasanIoT::sendData(const String& key, float value) {
    String json = "{\"key\":\"" + key + "\",\"value\":" + String(value, 2) + "}";
    return postJsonRaw("/ingest/device/" + String(_projectId), json);
}

bool WasanIoT::sendData(const String& key, int value) {
    String json = "{\"key\":\"" + key + "\",\"value\":" + String(value) + "}";
    return postJsonRaw("/ingest/device/" + String(_projectId), json);
}

bool WasanIoT::sendData(const String& key, bool value) {
    String json = "{\"key\":\"" + key + "\",\"value\":" + String(value ? "true" : "false") + "}";
    return postJsonRaw("/ingest/device/" + String(_projectId), json);
}

bool WasanIoT::sendData(const String& key, const String& value) {
    String json = "{\"key\":\"" + key + "\",\"value\":\"" + value + "\"}";
    return postJsonRaw("/ingest/device/" + String(_projectId), json);
}

// Poll for commands
String WasanIoT::pollCommands() {
    String response;
    if (getStrRaw("/devices/" + String(_deviceId) + "/poll", response)) {
        return response;
    }
    return "";
}

// Check WiFi connection
bool WasanIoT::isConnected() {
    return WiFi.status() == WL_CONNECTED;
}

// Command parsing helpers
bool WasanIoT::hasCommand(const String& response, const String& command) {
    // รองรับทั้ง "command" และ "cmd"
    return response.indexOf("\"command\":\"" + command + "\"") >= 0 || 
           response.indexOf("\"cmd\":\"" + command + "\"") >= 0;
}

bool WasanIoT::getCommandValue(const String& response, const String& command) {
    bool value = false;
    WasanUtils::parseCommand(response, command, value);
    return value;
}

int WasanIoT::getCommandIntValue(const String& response, const String& command) {
    int value = 0;
    WasanUtils::parseCommand(response, command, value);
    return value;
}

float WasanIoT::getCommandFloatValue(const String& response, const String& command) {
    float value = 0.0;
    WasanUtils::parseCommand(response, command, value);
    return value;
}

String WasanIoT::getCommandStringValue(const String& response, const String& command) {
    String value = "";
    WasanUtils::parseCommand(response, command, value);
    return value;
}

// Private HTTP methods
bool WasanIoT::postJsonRaw(const String& path, const String& json) {
    if (!_client.connect(_host, _port)) return false;
    
    _client.printf("POST %s HTTP/1.0\r\nHost: %s\r\nConnection: close\r\n", path.c_str(), _host);
    _client.print("Content-Type: application/json\r\n");
    _client.printf("Content-Length: %d\r\n", json.length());
    if (String(_apiKey).length()) _client.printf("x-api-key: %s\r\n", _apiKey);
    _client.print("\r\n");
    _client.print(json);
    
    unsigned long t0 = millis();
    while (_client.connected() && millis() - t0 < 4000) {
        while (_client.available()) _client.read();
    }
    _client.stop();
    delay(50);
    return true;
}

bool WasanIoT::getStrRaw(const String& path, String& out) {
    if (!_client.connect(_host, _port)) return false;
    
    _client.printf("GET %s HTTP/1.0\r\nHost: %s\r\nConnection: close\r\n", path.c_str(), _host);
    if (String(_apiKey).length()) _client.printf("x-api-key: %s\r\n", _apiKey);
    _client.print("\r\n");
    
    String resp;
    unsigned long t0 = millis();
    while (_client.connected() && millis() - t0 < 4000) {
        while (_client.available()) resp += (char)_client.read();
    }
    _client.stop();
    delay(30);
    
    int idx = resp.indexOf("\r\n\r\n");
    out = (idx >= 0) ? resp.substring(idx + 4) : resp;
    return true;
}

// Utility functions implementation
namespace WasanUtils {
    bool parseCommand(const String& response, const String& command, bool& value) {
        // รองรับทั้ง "command" และ "cmd"
        if (response.indexOf("\"command\":\"" + command + "\"") < 0 && 
            response.indexOf("\"cmd\":\"" + command + "\"") < 0) return false;
        
        // Check for different boolean formats
        if (response.indexOf("\"on\":true") >= 0 || 
            response.indexOf("\"value\":1") >= 0 || 
            response.indexOf("\"value\":true") >= 0) {
            value = true;
            return true;
        } else if (response.indexOf("\"on\":false") >= 0 || 
                   response.indexOf("\"value\":0") >= 0 || 
                   response.indexOf("\"value\":false") >= 0) {
            value = false;
            return true;
        }
        return false;
    }
    
    bool parseCommand(const String& response, const String& command, int& value) {
        // รองรับทั้ง "command" และ "cmd"
        if (response.indexOf("\"command\":\"" + command + "\"") < 0 && 
            response.indexOf("\"cmd\":\"" + command + "\"") < 0) return false;
        
        int start = response.indexOf("\"value\":");
        if (start < 0) return false;
        
        start += 8; // Skip "value":
        int end = response.indexOf(",", start);
        if (end < 0) end = response.indexOf("}", start);
        if (end < 0) return false;
        
        value = response.substring(start, end).toInt();
        return true;
    }
    
    bool parseCommand(const String& response, const String& command, float& value) {
        // รองรับทั้ง "command" และ "cmd"
        if (response.indexOf("\"command\":\"" + command + "\"") < 0 && 
            response.indexOf("\"cmd\":\"" + command + "\"") < 0) return false;
        
        int start = response.indexOf("\"value\":");
        if (start < 0) return false;
        
        start += 8; // Skip "value":
        int end = response.indexOf(",", start);
        if (end < 0) end = response.indexOf("}", start);
        if (end < 0) return false;
        
        value = response.substring(start, end).toFloat();
        return true;
    }
    
    bool parseCommand(const String& response, const String& command, String& value) {
        // รองรับทั้ง "command" และ "cmd"
        if (response.indexOf("\"command\":\"" + command + "\"") < 0 && 
            response.indexOf("\"cmd\":\"" + command + "\"") < 0) return false;
        
        int start = response.indexOf("\"value\":\"");
        if (start < 0) return false;
        
        start += 9; // Skip "value":
        int end = response.indexOf("\"", start);
        if (end < 0) return false;
        
        value = response.substring(start, end);
        return true;
    }
}
