#ifndef WASANIOT_H
#define WASANIOT_H

#include <WiFi.h>
#include <WiFiClient.h>

class WasanIoT {
private:
    const char* _ssid;
    const char* _password;
    const char* _host;
    uint16_t _port;
    const char* _projectId;
    const char* _deviceId;
    const char* _apiKey;
    WiFiClient _client;
    
    bool postJsonRaw(const String& path, const String& json);
    bool getStrRaw(const String& path, String& out);

public:
    // Constructor
    WasanIoT(const char* ssid, const char* password, const char* host, uint16_t port, 
             const char* projectId, const char* deviceId, const char* apiKey);
    
    // Initialize WiFi connection
    bool begin();
    
    // Send data methods
    bool sendData(const String& key, float value);
    bool sendData(const String& key, int value);
    bool sendData(const String& key, bool value);
    bool sendData(const String& key, const String& value);
    
    // Poll for commands
    String pollCommands();
    
    // Check WiFi connection
    bool isConnected();
    
    // Command parsing helpers
    bool hasCommand(const String& response, const String& command);
    bool getCommandValue(const String& response, const String& command);
    int getCommandIntValue(const String& response, const String& command);
    float getCommandFloatValue(const String& response, const String& command);
    String getCommandStringValue(const String& response, const String& command);
};

// Utility functions namespace
namespace WasanUtils {
    bool parseCommand(const String& response, const String& command, bool& value);
    bool parseCommand(const String& response, const String& command, int& value);
    bool parseCommand(const String& response, const String& command, float& value);
    bool parseCommand(const String& response, const String& command, String& value);
}

#endif // WASANIOT_H
